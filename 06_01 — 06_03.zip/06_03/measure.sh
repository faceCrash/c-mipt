set -e

echo "=== Building 06_01 ==="
time clang++ -std=gnu++23 -Wall -Wextra -c 06_01/Rational.cpp -o 06_01/Rational.o
time clang++ -std=gnu++23 -Wall -Wextra -c 06_01/main.cpp -o 06_01/main.o
time clang++ 06_01/Rational.o 06_01/main.o -o 06_01/main
ls -lh 06_01/*.o 06_01/main

echo
echo "=== Building 06_02 ==="
time clang++ -std=gnu++23 -Wall -Wextra -c 06_02/Rational.cpp -o 06_02/Rational.o
time clang++ -std=gnu++23 -Wall -Wextra -c 06_02/main.cpp -o 06_02/main.o
time clang++ 06_02/Rational.o 06_02/main.o -o 06_02/main
ls -lh 06_02/*.o 06_02/main
