#pragma once
#include <iostream>
#include <numeric>
#include <cmath>

namespace task0602 {

class Rational {
public:
    Rational(int num = 0, int den = 1) : m_num(num), m_den(den) { reduce(); }

    explicit operator double() const { return static_cast<double>(m_num) / m_den; }

    Rational& operator+=(const Rational& other) {
        auto lcm_den = std::lcm(m_den, other.m_den);
        m_num = m_num * (lcm_den / m_den) + other.m_num * (lcm_den / other.m_den);
        m_den = lcm_den;
        reduce();
        return *this;
    }

    Rational& operator-=(const Rational& other) { return *this += Rational(-other.m_num, other.m_den); }

    Rational& operator*=(const Rational& other) { m_num *= other.m_num; m_den *= other.m_den; reduce(); return *this; }

    Rational& operator/=(const Rational& other) { return *this *= Rational(other.m_den, other.m_num); }

    Rational operator++(int) { Rational tmp(*this); *this += 1; return tmp; }
    Rational operator--(int) { Rational tmp(*this); *this -= 1; return tmp; }

    Rational& operator++() { *this += 1; return *this; }
    Rational& operator--() { *this -= 1; return *this; }

    friend Rational operator+(Rational lhs, const Rational& rhs) { return lhs += rhs; }
    friend Rational operator-(Rational lhs, const Rational& rhs) { return lhs -= rhs; }
    friend Rational operator*(Rational lhs, const Rational& rhs) { return lhs *= rhs; }
    friend Rational operator/(Rational lhs, const Rational& rhs) { return lhs /= rhs; }

    friend bool operator==(const Rational& lhs, const Rational& rhs) { return lhs.m_num == rhs.m_num && lhs.m_den == rhs.m_den; }
    friend bool operator!=(const Rational& lhs, const Rational& rhs) { return !(lhs == rhs); }

    friend std::ostream& operator<<(std::ostream& os, const Rational& r) { return os << r.m_num << '/' << r.m_den; }
    friend std::istream& operator>>(std::istream& is, Rational& r) { char sep; return is >> r.m_num >> sep >> r.m_den; }

private:
    void reduce() {
        if (m_den < 0) { m_num = -m_num; m_den = -m_den; }
        int g = std::gcd(m_num, m_den);
        if (g != 0) { m_num /= g; m_den /= g; }
    }

    int m_num;
    int m_den;
};

} // namespace task0602
