#include "Rational.hpp"
#include <numeric>

namespace task0601 {

Rational& Rational::operator+=(const Rational& other) {
    int lcm = std::lcm(m_den, other.m_den);
    m_num = m_num * (lcm / m_den) + other.m_num * (lcm / other.m_den);
    m_den = lcm;
    reduce();
    return *this;
}

Rational& Rational::operator-=(const Rational& other) {
    return *this += Rational(-other.m_num, other.m_den);
}

Rational& Rational::operator*=(const Rational& other) {
    m_num *= other.m_num;
    m_den *= other.m_den;
    reduce();
    return *this;
}

Rational& Rational::operator/=(const Rational& other) {
    return *this *= Rational(other.m_den, other.m_num);
}

Rational& Rational::operator++() { return *this += Rational(1); }
Rational& Rational::operator--() { return *this -= Rational(1); }
Rational Rational::operator++(int) { auto t = *this; ++(*this); return t; }
Rational Rational::operator--(int) { auto t = *this; --(*this); return t; }

void Rational::reduce() {
    if (m_den < 0) { m_num = -m_num; m_den = -m_den; }
    int g = std::gcd(m_num, m_den);
    m_num /= g;
    m_den /= g;
}

std::strong_ordering operator<=>(const Rational& lhs, const Rational& rhs) {
    int l = lhs.m_num * rhs.m_den;
    int r = rhs.m_num * lhs.m_den;
    if (l < r) return std::strong_ordering::less;
    if (l > r) return std::strong_ordering::greater;
    return std::strong_ordering::equal;
}

bool operator==(const Rational& lhs, const Rational& rhs) {
    return (lhs <=> rhs) == std::strong_ordering::equal;
}

std::istream& operator>>(std::istream& is, Rational& r) {
    char slash;
    is >> r.m_num >> slash >> r.m_den;
    r.reduce();
    return is;
}

std::ostream& operator<<(std::ostream& os, const Rational& r) {
    return os << r.m_num << '/' << r.m_den;
}

} // namespace task0601
