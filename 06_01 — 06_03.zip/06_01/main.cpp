#include "Rational.hpp"
#include <cassert>
#include <sstream>
#include <cmath>

using task0601::Rational;

bool equal(double a, double b, double eps = 1e-6) { return std::abs(a - b) < eps; }

int main() {
    Rational x = 1, y(2, 1);
    assert(equal(static_cast<double>(x), 1.0));
    assert((x += y) == Rational(3));
    assert((x -= y) == Rational(1));
    assert((x *= y) == Rational(2));
    assert((x /= y) == Rational(1));

    assert((x++) == Rational(1));
    assert((x--) == Rational(2));
    assert((++y) == Rational(3));
    assert((--y) == Rational(2));

    assert((x + y) == Rational(3));
    assert((x - y) == Rational(-1));
    assert((x * y) == Rational(2));
    assert((x / y) == Rational(1, 2));

    Rational a(1, 2), b(2, 4), c(3, 4), d(-1, 2);
    assert(a == b);
    assert(a != c);
    assert(a < c);
    assert(c > a);
    assert(a <= b);
    assert(c >= a);
    assert(d < a);

    std::stringstream ss("10/20");
    Rational z;
    ss >> z;
    assert(z == Rational(1, 2));

    std::stringstream ss_out;
    ss_out << z;
    assert(ss_out.str() == "1/2");

    return 0;
}
