#pragma once
#include <iostream>
#include <numeric>
#include <compare>

namespace task0601 {

class Rational {
public:
    Rational(int num = 0, int den = 1) : m_num(num), m_den(den) { reduce(); }

    explicit operator double() const { return static_cast<double>(m_num) / m_den; }

    Rational& operator+=(const Rational& other);
    Rational& operator-=(const Rational& other);
    Rational& operator*=(const Rational& other);
    Rational& operator/=(const Rational& other);

    Rational& operator++();
    Rational& operator--();
    Rational operator++(int);
    Rational operator--(int);

    friend Rational operator+(Rational lhs, const Rational& rhs) { return lhs += rhs; }
    friend Rational operator-(Rational lhs, const Rational& rhs) { return lhs -= rhs; }
    friend Rational operator*(Rational lhs, const Rational& rhs) { return lhs *= rhs; }
    friend Rational operator/(Rational lhs, const Rational& rhs) { return lhs /= rhs; }

    friend std::strong_ordering operator<=>(const Rational& lhs, const Rational& rhs);
    friend bool operator==(const Rational& lhs, const Rational& rhs);

    friend std::istream& operator>>(std::istream& is, Rational& r);
    friend std::ostream& operator<<(std::ostream& os, const Rational& r);

private:
    void reduce();

    int m_num = 0;
    int m_den = 1;
};

} // namespace task0601
